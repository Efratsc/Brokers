package com.example.androidprojct;

public class PostedUserDetailActivity {
}
