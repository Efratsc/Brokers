package com.example.androidprojct;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androidprojct.models.PostModel;

import java.util.List;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.MyViewHolder>{
     private Context con;
    private List<PostModel> postModelList;

    public PostAdapter(Context con, List<PostModel> postModelList) {
        this.con = con;
        this.postModelList = postModelList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.post_view,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return postModelList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        private TextView username,textpost;
        private ImageView userprofile,postimage,rate,comment;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            username=itemView.findViewById(R.id.username);
            textpost=itemView.findViewById(R.id.postText);
            userprofile=itemView.findViewById(R.id.userimage);
            postimage=itemView.findViewById(R.id.postimage);
            rate=itemView.findViewById(R.id.rate);
            comment=itemView.findViewById(R.id.connect);
        }
    }
}
